//
//  ViewController.swift
//  MenuBuilder
//
//  Created by Nikhil Nigade on 29/09/22.
//

import UIKit

final class ViewController: UIViewController {
  
  override func viewDidLoad() {
    super.viewDidLoad()
    // Do any additional setup after loading the view.
  }
  
  override var canBecomeFirstResponder: Bool {
    true
  }
}

